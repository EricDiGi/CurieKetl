## Scripts

This directory contains scripts that are used by pipelines. The scripts are not intended to be run directly, but rather are called by pipelines. The scripts are organized by pipeline and by execution mode (run/save). 

**Rules:** Scripts should be named according to the table they belong to. While not necessary, it's highly recommended that you use a well-named directory structure to assign a script to a pipeline and execution mode. 