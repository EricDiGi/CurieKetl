document.getElementsByClassName("md-button-disabled")
    .forEach(
        function (element) {
            element.disabled = true;
        }
    );