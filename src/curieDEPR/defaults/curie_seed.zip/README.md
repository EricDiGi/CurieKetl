# Welcome to you Curie Project!

I'm so happy to see you here! Have a look around and enjoy building your own Curie Project!

> __Please Remember:__ All relative file paths are relative to the root of the project. So if you want to link to a file in the `docs` folder, you would use `docs/README.md` as the path.