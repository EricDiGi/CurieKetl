## Data

Downloads from saving pipelines and other data.

**Rules:** Best practice is to store data according to the pipeline it belongs to. Use a well-named directory structure to acheive this.